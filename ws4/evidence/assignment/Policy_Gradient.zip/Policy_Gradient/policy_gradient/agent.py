import torch
import torch.nn as nn
import torch.optim as optim

import numpy as np
from policy_gradient.network import GaussianPolicy, CategoricalPolicy, ValueNet
from gymnasium.spaces import Discrete

class PGAgent:
    def __init__(self, env, device='cpu',
                 hidden_size=64, layer_num=2,
                 use_reward_to_go=False, use_baseline=False,
                 gamma=0.99, 
                 gae_lambda=1.0, 
                 actor_lr=1e-3, critic_lr=1e-3, 
                 normalize_advantage=False):
        
        self.device = device
        self.discrete = isinstance(env.action_space, Discrete)
        self.state_dim = env.observation_space.shape[0]
        self.act_dim = env.action_space.n if self.discrete else env.action_space.shape[0]
        self.use_reward_to_go = use_reward_to_go 
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.use_baseline = use_baseline
        self.normalize_advantage = normalize_advantage

        assert not (use_reward_to_go and use_baseline), \
            "cannot apply reward-to-go and baseline at the same time"
        assert not (use_reward_to_go and (gae_lambda < 1.0)), \
            "cannot apply reward-to-go and gae at the same time"
        
        if self.discrete:
            self.actor = CategoricalPolicy(self.state_dim, self.act_dim, hidden_size, layer_num)
        else:
            self.actor = GaussianPolicy(self.state_dim, self.act_dim, hidden_size, layer_num)
            self.action_low = env.action_space.low
            self.action_high = env.action_space.high

        # value network if needed
        if (gae_lambda < 1.0):
            self.critic = ValueNet(self.state_dim, hidden_size, layer_num)
            self.critic_loss = nn.MSELoss()
        else:
            self.critic = None
        
        self.actor.to(self.device)

        if self.critic is not None:
            self.critic.to(self.device)

        self.optimizer_policy = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.optimizer_value = optim.Adam(self.critic.parameters(), lr=critic_lr) if self.critic else None


    def sample_action(self, state_np):
        
        state = torch.tensor(state_np, dtype=torch.float32).unsqueeze(0).to(self.device)        


        ### (TODO) Forward the actor network to get a distribution of action: actor.forward(...)
        action_distribution = ...

        ### (TODO) Sample the distribution        
        action = ...


        # Convert action to numpy
        action = action.cpu().numpy().squeeze()
        if not self.discrete:
            action = action.clip(self.action_low, self.action_high)
        
        return action

    def generalized_advantage_estimation(self, state_np, next_state_np, rewards, terminateds, dones):
        ### (TODO - W11) - Generalized Advantage Estimation
        states = torch.tensor(np.asarray(state_np), dtype=torch.float32, device=self.device)
        next   = torch.tensor(np.asarray(next_state_np), dtype=torch.float32, device=self.device)
        with torch.no_grad():
            values      = self.critic(states).squeeze(-1).cpu().numpy()
            next_values = self.critic(next).squeeze(-1).cpu().numpy()

        rewards     = np.asarray(rewards, dtype=np.float32)
        terminateds = np.asarray(terminateds, dtype=np.float32)
        dones       = np.asarray(dones, dtype=np.float32)

        advantages = ...
        returns = ...


        return returns, advantages



    def update(self, batch):
        rewards, states, actions, dones = \
            batch['rewards'], batch['states'], batch['actions'], batch['dones']

        ### (TODO) Split rewards into trajectories using done flags
        ### A trajectory ends when done==True 
        ### The achieved reward_trajectories is a list of numpy arrays, each array is a trajectory of rewards
        reward_trajectories = []
        
        ### (TODO) Calculate returns and advantages
        if self.critic is None:
            ### self._discounted_reward_to_go and self._discounted_return calculate returns for a single trajectory
            ### returns and advantages must be concatenated into vector
            
            if not self.use_reward_to_go:
                ### (TODO) If no variance reduction technique is used, calculate the returns
                returns = ...

            else:
                ### (TODO) If reward-to-go is used, calculate the returns
                returns = ...

            if (not self.use_baseline) or self.use_reward_to_go:        
                ### (TODO) For the original Policy Gradient or reward-to-go, advantages = returns
                advantages = ...            

            else:
                ### (TODO) If baseline is selected, calculate the baseline and the advantages                
                advantages = ...


        ### (TODO - W11) Genaralized Advantage Estimation
        else:
            returns, advantages = ...

        ### (TODO - W11) Normalize the advantages of the batch to have a mean of 0 and a standard deviation of 1
        if self.normalize_advantage:
            advantages = ...

        # Convert to tensors
        states = torch.tensor(states, dtype=torch.float32, device=self.device)
        actions = torch.tensor(actions, dtype=torch.float32, device=self.device)
        returns = torch.tensor(returns, dtype=torch.float32, device=self.device)
        advantages = torch.tensor(advantages, dtype=torch.float32, device=self.device)


        ### (TODO) Compute log probabilities of selected actions, 
        ### Sum across the action dimension so each sample has a single log-prob value.
        log_pi = ...

        ### (TODO) Compute policy gradient loss: -E[log_pi * advantage]
        actor_loss = ...

        
        self.optimizer_policy.zero_grad()
        actor_loss.backward()
        self.optimizer_policy.step()

        critic_loss = None
        if self.critic:
            prediction = self.critic(states).squeeze()
            critic_loss = self.critic_loss(prediction, returns)
            self.optimizer_value.zero_grad()
            critic_loss.backward()
            self.optimizer_value.step()

        return {
            "actor_loss": actor_loss.item(),
            "critic_loss": critic_loss.item() if critic_loss is not None else None,
            "mean_log_pi": log_pi.mean().item(),
            "advantage_mean": advantages.mean().item(),
            "advantage_std": advantages.std().item()
        }
    
    def _discounted_return(self, traj_reward):
        ### (TODO) Compute the return for each trajectory, extend to the size of rewards
        # In PG, we use the same discounted return for the entire trajectory.
        returns = ...
        return returns
    
    
    def _discounted_reward_to_go(self, traj_reward):
        ### (TODO) Compute the return for each step in the trajectory
        # With reward-to-go, the return is computed for each step using only the future timesteps
        returns = ...
        return returns