import gymnasium as gym
import numpy as np
import torch
import argparse
import os
import time

from policy_gradient.agent import PGAgent
from utils.util import collect_trajectories
from utils.logger import Logger


def train(args):
    log_dir = "logs/"
    log_dir = os.path.join(log_dir, args.env_name)    
    log_name = "PG" 
    if args.exp_name:
        log_name = log_name + "_" + args.exp_name

    log_name = log_name + "_" + time.strftime("%d-%m-%Y_%H-%M-%S")
    log_dir = os.path.join(log_dir, log_name)
    if not (os.path.exists(log_dir)):
        os.makedirs(log_dir)
    logger = Logger(log_dir=log_dir)
    
    render_mode = None
    if args.render:
        render_mode="human"
    
    env = gym.make(args.env_name, render_mode=render_mode)
    eval_env = gym.make(args.env_name)

    agent = PGAgent(env, device=args.device,
                    hidden_size=args.hidden_size, layer_num=args.layer_num,
                    gamma=args.discount_gamma, 
                    use_reward_to_go=args.use_reward_to_go,
                    use_baseline=args.use_baseline,
                    normalize_advantage=args.normalize_advantage,
                    actor_lr=args.learning_rate,
                    critic_lr=args.baseline_learning_rate, 
                    gae_lambda=args.gae_lambda)

    total_envsteps = 0
    update_idx = 0
    next_eval = args.eval_every
    next_video = args.video_every

    while total_envsteps < args.total_steps:

        batch = {'states':[], 'next_states':[], 'actions':[], 'rewards':[], 'terminateds':[], 'dones':[]}
        ep_returns = []
        steps_this_batch = 0

        while steps_this_batch < args.batch_steps:
            
            states, next_states, actions, rewards, terminateds, dones = [],[],[],[],[],[]

            state, _ = env.reset()
            episode_reward = 0
            episode_step = 0
            done = False

            while not done:

                ### (TODO) Get the action from the policy with the most recent state
                action = ...

                ### (TODO) use that action to take a step in the environment
                step_result = ...

                next_state, reward, terminated, truncated, info = step_result
                done = terminated or truncated

                # Record result of taking that action
                states.append(state)
                next_states.append(next_state)
                actions.append(action)                        
                rewards.append(reward)
                terminateds.append(terminated)
                dones.append(done)

                state = next_state
                episode_reward += reward
                episode_step += 1
                total_envsteps += 1
                
                
            batch["states"].append(states)
            batch["next_states"].append(next_states)
            batch["actions"].append(actions)
            batch["rewards"].append(rewards)
            batch["terminateds"].append(terminateds)
            batch["dones"].append(dones)
            
            ep_returns.append(sum(rewards))
            steps_this_batch += len(rewards)

            if args.render:
                time.sleep(0.05)
            

        for k in batch:
            batch[k] = np.concatenate(batch[k])

        
        ### (TODO) update the agent using the sampled batch
        update_info = ...


        update_idx += 1

        ### Logging
        logstep = total_envsteps
        
        logger.log_scalar(update_info["actor_loss"], "Training/Policy Loss", logstep)
        if update_info["critic_loss"]:
            logger.log_scalar(update_info["critic_loss"], "Training/Critic Loss", logstep)

        logger.log_scalar(update_info["mean_log_pi"], "Training/Mean Log Pi", logstep)
        logger.log_scalar(update_info["advantage_mean"], "Training/Advantages Mean", logstep)
        logger.log_scalar(update_info["advantage_std"], "Training/Advantages Std", logstep)

        train_return = np.mean(ep_returns)
        logger.log_scalar(train_return, "Training/Train Returns", logstep)
        logger.log_scalar(len(ep_returns), "Training/Episodes per Batch", logstep)

        if total_envsteps >= next_eval:
            next_eval += args.eval_every                   
            eval_batch = collect_trajectories(eval_env, agent, batch_size=5, render=False)
            # eval_return = np.sum(eval_batch['rewards'])
            # logger.log_scalar(eval_return, "Eval Returns", logstep)
            
            eval_returns = [np.sum(traj) for traj in eval_batch['rews_list']] 
            
            logger.log_scalar(np.mean(eval_returns), "Eval Returns", logstep)
            logger.log_scalar(np.std(eval_returns), "Eval Returns Std", logstep)
            print(f"Update {update_idx} | steps {total_envsteps}/{args.total_steps} | "
                f"eval {np.mean(eval_returns):.1f} | actor loss {update_info['actor_loss']:.4f}")
        
        if args.log_video and total_envsteps >= next_video:
            next_video += args.video_every           
            render_env = gym.make(args.env_name,render_mode="rgb_array")
            final_batch = collect_trajectories(render_env, agent, 1, render=True)
            video = torch.tensor(final_batch['images']).permute(0,1,4,2,3)  # [N,T,H,W,C] → [N,T,C,H,W]
            print("Logging video")
            logger.log_video(video, "Video", step=total_envsteps)
    

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Policy Gradient")
    parser.add_argument("--env_name", type=str, required=True, help="gym environment") 
    parser.add_argument("--total_steps", type=int, default=500_000, help="total env steps to train for")
    parser.add_argument("--batch_steps", type=int, default=1000, help="min env steps per update")
    parser.add_argument("--eval_every", type=int, default=10_000, help="env steps between evals")
    parser.add_argument("--video_every", type=int, default=100_000, help="env steps between videos")

    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--discount_gamma", type=float, default=0.9)
    
    parser.add_argument("--layer_num", type=int, default=2, help="neural network layer number")
    parser.add_argument("--hidden_size", type=int, default=64, help="neural network hidden layer size")

    parser.add_argument("--use_reward_to_go", action="store_true")
    parser.add_argument("--use_baseline", action="store_true")
    
    parser.add_argument("--normalize_advantage", action="store_true")
    parser.add_argument("--gae_lambda", type=float, default=1.0) 
    parser.add_argument("--baseline_learning_rate", type=float, default=1e-3)
    parser.add_argument("--render", action="store_true", help="whether to render")      
    parser.add_argument("--log_video", action="store_true")
    parser.add_argument("--exp_name", default=None, help="add extra info (parameters) to log")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print('########################')
    print(f"Device: {device}")
    args.device = device

    train(args)
